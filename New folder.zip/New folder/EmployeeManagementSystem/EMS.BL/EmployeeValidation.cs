﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using EMS.DAL;
using System.Data;

namespace EMS.BL
{
    public class EmployeeValidation
    {
        public DataTable LoadDepartment()
        {
            try
            {
                Operations empOp = new Operations();
                return empOp.LoadDepartment();
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
    }
}
