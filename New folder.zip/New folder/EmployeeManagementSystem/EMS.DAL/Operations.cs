﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Configuration;
using EMS.Entity;
using EMS.Exception;
using System.Data;

namespace EMS.DAL
{
    public class Operations
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        DataTable dt, dtemp = null;



        static Operations()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public Operations()
        {
            con = new SqlConnection(conStr);

        }

        public DataTable LoadDepartment()
        {
            

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Akshita.usp_GetDepartment";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;


        }

        public int AddEmployee_Dal(Employee emp)
        {
            int rowsAffected = 0;
            try
            {
                
                cmd = new SqlCommand("Akshita.usp_AddEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pName", emp.EmployeeName);
                cmd.Parameters.AddWithValue("@descp", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@up", emp.EmployeeLocation);
                cmd.Parameters.AddWithValue("@st", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@cat", emp.PhoneNo);
                con.Open();
                rowsAffected = cmd.ExecuteNonQuery();
            }

            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return rowsAffected;
        }

        //public DataTable GetEmployee_DAL()
        //{
        //    try
        //    {
        //        com
        //    }
        //    catch (System.Exception)
        //    {

        //        throw;
        //    }

        //}

    }
}
