﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Purpose: To Create an Entity Class with the Properties
    /// </summary>
    public class Employee
    {
        //Property for EmployeeID
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public int DepartmentID { get; set; }
        public string EmployeeLocation { get; set; }
        public string PhoneNo { get; set; }

    }
}
